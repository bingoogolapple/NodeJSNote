package cn.bingoogolapple.uiautomator;

import android.os.Bundle;
import android.os.RemoteException;

import com.android.uiautomator.core.UiDevice;
import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

/**
 * android.jar uiautomator.jar位于sdk/platform/对应sdk版本下
 * 
 * android create uitest-project -n <jars> -t <sdkId，通常为1> -p <workspace path>
 * android list 查看sdkId android create uitest-project -n uiautomator -t 1
 * -<workspace path>
 * 
 * 
 * android create uitest-project -n uiautomator -t 1 -p E:\workspace\UIAutomator
 * 
 * 
 * 
 * 修改build.xml <project name="uiautomator" default="help"> ----> <project
 * name="uiautomator" default="build">
 * 
 * 
 * ant -buildfile build.xml
 * 
 * adb push ./bin/uiautomator.jar /data/local/tmp/
 * 
 * 
 * adb shell uiautomator runtest uiautomator.jar -c
 * cn.bingoogolapple.uiautomator.Test adb shell uiautomator runtest
 * uiautomator.jar -c cn.bingoogolapple.uiautomator.Test#testMenu
 * 
 * 
 * adb shell uiautomator runtest uiautomator.jar -c
 * cn.bingoogolapple.uiautomator.Test#testMenu -c
 * cn.bingoogolapple.uiautomator.Test#testHome
 */
public class Test extends UiAutomatorTestCase {

	public void testHome() {
		UiDevice uiDevice = UiDevice.getInstance();
		uiDevice.pressHome();
	}

	public void testBack() {
		UiDevice uiDevice = UiDevice.getInstance();
		uiDevice.pressBack();
	}

	public void testMenu() {
		UiDevice uiDevice = UiDevice.getInstance();
		uiDevice.pressMenu();
	}

	public void testRecent() throws RemoteException {
		UiDevice uiDevice = UiDevice.getInstance();
		uiDevice.pressRecentApps();
	}

	// adb shell uiautomator runtest uiautomator.jar -c
	// cn.bingoogolapple.uiautomator.Test#testPrintln -e phone 11111111111
	public void testPrintln() {
		Bundle bundle = getParams();
		String phone = bundle.getString("phone");
		System.out.println("PHONE = " + phone);
	}

	public void testChrome() throws UiObjectNotFoundException {
		UiDevice uiDevice = UiDevice.getInstance();
		uiDevice.pressHome();
		UiObject browserObject = new UiObject(new UiSelector().text("Chrome"));
		browserObject.clickAndWaitForNewWindow();
		UiObject editTextObject = new UiObject(new UiSelector().className("android.widget.EditText"));
		editTextObject.click();
		uiDevice.pressDelete();
		editTextObject.setText("www.baidu.com");
		uiDevice.pressEnter();
		sleep(2000);
	}

	public void testMovie() throws UiObjectNotFoundException {
		UiDevice uiDevice = UiDevice.getInstance();
		uiDevice.pressHome();
		sleep(1000);
		UiObject alipay = new UiObject(new UiSelector().text("支付宝钱包"));
		alipay.clickAndWaitForNewWindow();

		for (int i = 0; i < 5; i++) {
			UiObject movie = new UiObject(new UiSelector().text("淘宝电影"));
			movie.clickAndWaitForNewWindow();
			uiDevice.pressBack();
		}
		uiDevice.pressHome();
	}

	public void testAlipay() throws UiObjectNotFoundException {
		UiDevice uiDevice = UiDevice.getInstance();
		uiDevice.pressHome();
		sleep(1000);
		UiObject alipay = new UiObject(new UiSelector().text("支付宝钱包"));
		alipay.clickAndWaitForNewWindow();
		sleep(4000);

		int height = uiDevice.getDisplayHeight() - 10;
		int width = uiDevice.getDisplayWidth() - 10;
		
		for (int i = 0; i < 100; i++) {
			for(int x = 50; x < width;) {
				for(int y= 100; y < height;) {
					uiDevice.click(x, y);
					
					y += 100;
				}
				
				x += 100;
			}
		}	
		uiDevice.pressHome();
	}


	/*
	         抢完后停止uiautomator
		adb shell
		ps | grep uiautomator
		kill 进程号
	*/
	public static void main(String[] args) {
		String jarName = "uiautomator";
		String testClass = "cn.bingoogolapple.uiautomator.Test";
		String testName = "testAlipay";
		String androidId = "1";
		new UiAutomatorHelper(jarName, testClass, testName, androidId);
	}

}